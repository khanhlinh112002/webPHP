<?php

    include_once("./connect.php");
    paginate::createPagination();

?>