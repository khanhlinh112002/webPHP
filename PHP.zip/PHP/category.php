<?php

    class category{
        private string $idCategory;
        private string $category;


        public function __construct($category) {
            $this->idCategory = "";
            $this->category = $category;
        }

        
    }

?>