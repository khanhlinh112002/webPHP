<!DOCTYPE html>
<html>

<head>
    <title>Home5</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta content="text/html; charset=iso-8859-2" http-equiv="Content-Type">
    <link rel="stylesheet" href="../../assets/css/home2.css">

</head>

<body>

    <div class="container">
        <div class="content">
            <img class="image" src="../../assets/image/img4.jpg" style="width:60%">
        </div>
        <div class="title">

            <h1>Gates of Hue</h1>
        </div>
        <div id="bro"></div>
        <div class="menu">
            <ul class="main_menu">
                <li>
                    <a href="../../user/page/index.php">Home</a>
                </li>
                <li>
                Gates of Hue
                </li>
            </ul>
        </div>
        <br><br><br>
        <div class="the">
            <i>Heavy traffic on a cloudy day as folks make the late afternoon commute back home.
                 One thing I truly love about this city is the fact that just by driving across town, a person may pass under,
                  over, and around half-a-dozen reminders that they are in a city built around a castle.
                   Americans have no concept of this kind of ancient history. For American culture is a young culture, 
                and its artifacts are those of the peoples killed by Europeans to make room for Manifest Destiny..</i>
        </div>
    </div>
</body>
</html></i>
        </div>
    </div>
</body>
</html>