<!DOCTYPE html>
<html>

<head>
    <title>Hom1</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta content="text/html; charset=iso-8859-2" http-equiv="Content-Type">
    <link rel="stylesheet" href="../../assets/css/home1.css">

</head>

<body>


    <div class="container">
        <div class="content">
            <img class="image" src="../../assets/image/img7.jpg" style="width:60%">
        </div>
        <div class="title">

            <h1>Photograph of a hardworking woman in Vietnam</h1>
        </div>
        <div id="bro"></div>
        <div class="menu">
            <ul class="main_menu">
                <li>
                    <a href="../../user/page/index.php">Home</a>
                </li>
                <li>
                    Photograph of a woman in Vietnam
                </li>
            </ul>
        </div>
        <br><br><br>
        <div class="the">
            <i>When I look at her my eyes glaze over and I lose myself in the lines of her face.
                 Life becomes a bit sweeter. I see myself and the sky in her eyes. And so can you, if you look closely.
                  She is my grandmother. She is your grandmother.
                 Treat her well and she will bless you with the wisdom of the years.</i>
        </div>
    </div>