<!DOCTYPE html>
<html>

<head>
    <title>Home5</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta content="text/html; charset=iso-8859-2" http-equiv="Content-Type">
    <link rel="stylesheet" href="../../assets/css/home2.css">

</head>

<body>

    <div class="container">
        <div class="content">
            <img class="image" src="../../assets/image/26.jpg" style="width:60%">
        </div>
        <div class="title">

            <h1>Gates of Hue</h1>
        </div>
        <div id="bro"></div>
        <div class="menu">
            <ul class="main_menu">
                <li>
                <a href="../../user/page/index.php">Home</a>
                </li>
                <li>
                Gates of Hue
                </li>
            </ul>
        </div>
        <br><br><br>
        <div class="the">
            <i>A few kilometers outside Hue City is a small village and a bridge that will take you back in time.
                 Couples will come out here to take wedding pictures, and the village itself is
                 about as close to untouched by the 21st Century as a person will find in Central Vietnam.</i>
        </div>
    </div>
</body>
</html>