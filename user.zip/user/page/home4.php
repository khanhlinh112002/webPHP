<!DOCTYPE html>
<html>

<head>
    <title>Hom2</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta content="text/html; charset=iso-8859-2" http-equiv="Content-Type">
    <link rel="stylesheet" href="../../assets/css/home2.css">

</head>

<body>

    <div class="container">
        <div class="content">
            <img class="image" src="../../assets/image/img5.jpg" style="width:60%">
        </div>
        <div class="title">

            <h1>Vietnam field green Photograph</h1>
        </div>
        <div id="bro"></div>
        <div class="menu">
            <ul class="main_menu">
                <li>
                <a href="../../user/page/index.php">Home</a>
                </li>
                <li>
                Vietnam field green Photograph
                </li>
            </ul>
        </div>
        <br><br><br>
        <div class="the">
            <i>One thing I really enjoy doing is kneeling down and shooting up. 
                It makes me look ridiculous enough to ensure people don’t take me seriously and gives me
                 a bird’s eye view of conversations. Sometimes I end up shooting a whole lot of feet,
                  but I usually end up with a few nice pics.
</i>
        </div>
    </div>
</body>
</html>