<!DOCTYPE html>
<html>

<head>
    <title>Hom3</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta content="text/html; charset=iso-8859-2" http-equiv="Content-Type">
    <link rel="stylesheet" href="../../assets/css/home2.css">

</head>

<body>

    <div class="container">
        <div class="content">
            <img class="image" src="../../assets/image/img9.jpg" style="width:60%">
        </div>
        <div class="title">

            <h1>Photograph of a  father and daughter</h1>
        </div>
        <div id="bro"></div>
        <div class="menu">
            <ul class="main_menu">
                <li>
                <a href="../../user/page/index.php">Home</a>
                </li>
                <li>
                Photograph of a  father and daughter
                </li>
            </ul>
        </div>
        <br><br><br>
        <div class="the">
            <i>If a person has the patience to just stay somewhere awhile, 
                interesting things are going to happen and that person will see them. In other words,
                 chill out and you’ll be rewarded. We move far too quickly in today’s 
                world and miss out on many, many beautiful things and beautiful people in the process..</i>
        </div>
    </div>
</body>
</html>